using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("Low Orbit Ion Cannon")]
[assembly: AssemblyDescription("TCP/IP stress-test tool")]
[assembly: AssemblyProduct("Low Orbit Ion Cannon")]
[assembly: AssemblyCopyright("Public Domain")]

[assembly: System.Resources.NeutralResourcesLanguage("en-US")]

[assembly: System.CLSCompliant(true)]
[assembly: ComVisible(false)]

[assembly: Guid("312adafc-fdac-484b-84c5-5c5457e47f67")]

[assembly: AssemblyVersion("1.0.7.0")]
